package com.mypoc.core;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;


@Configuration
@EnableScheduling
public class ScheduledConfiguration {
	
	static final Logger logger = Logger.getLogger(ScheduledConfiguration.class);
	
    @Scheduled(fixedRate = 30000)
    public void executeTask1() { //For every 30 seconds
        logger.info(Thread.currentThread().getName() + " The Task1 executed at "+ new Date());
        try {
            Thread.sleep(2000);
            WorkerThread worker = new WorkerThread("Cache processing.");
            worker.run();
            
          } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Scheduled(fixedRate = 600000)
    public void executeTask2() { //For every 60 seconds
    	logger.info(Thread.currentThread().getName()+" Sample Task2 executed at "+ new Date());
    }
}