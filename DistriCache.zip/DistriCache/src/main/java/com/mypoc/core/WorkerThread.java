package com.mypoc.core;

import java.util.Date;

import org.apache.log4j.Logger;

public class WorkerThread implements Runnable {

	static final Logger logger = Logger.getLogger(WorkerThread.class);

	private String command;

	public WorkerThread(String s) {
		this.command = s;
	}

	@Override
	public void run() {

		logger.info(Thread.currentThread().getName() + " Start. Time = " + new Date());
		processCommand();
		logger.info(Thread.currentThread().getName() + " End. Time = " + new Date());
	}

	private void processCommand() {
		try {
			DistriCacheImpl.invalidateCache();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return this.command;
	}
}