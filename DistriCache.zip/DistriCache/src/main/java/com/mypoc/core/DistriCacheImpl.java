package com.mypoc.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component

   public class DistriCacheImpl {
	
	static final Logger logger = Logger.getLogger(DistriCacheImpl.class);
	
	public static final Map<String, String> MESSAGE_CACHE = new HashMap<String, String>();
	
	public static String initCache(String hostname) {
		
		String jsonString ="";
		KafkaClient client = new KafkaClient();
		
		try {
			ConsumerRecords<String, String> cRecords = client.kafkaConsumerPolling(hostname + ":9092");
			
			if(cRecords.isEmpty()) {
				String json = "{name: \"Hildon\", age: 37, city: \"SingaporeCapital\"}";
				populateConsumerRecords(cRecords);
				MESSAGE_CACHE.put("testkey1", json);
			} else {
				for (ConsumerRecord<String, String> record: cRecords) {
					MESSAGE_CACHE.put(record.key().toString(), record.value().toString());
					logger.debug( "\nMessage Key: " + record.key().toString() + " Message value : " + record.value().toString());
				}
			}
		} catch (Exception e1) {
			logger.error(e1.getMessage());
			e1.printStackTrace();
		}
		displayCache();
		return jsonString;		
	}
	
	public static void invalidateCache() {

		MESSAGE_CACHE.clear();
		logger.info("Cache Invalidated");
		
	}
	
	public static String lookupCache(String key) {
		
		return MESSAGE_CACHE.get(key);
	}
	
	public static void displayCache() {

		Set<Entry<String, String>> entrySet =  MESSAGE_CACHE.entrySet();
		
		for (Map.Entry<String, String> entry : entrySet) {
			logger.info("\nCache key: " + entry.getKey().toString() + "Cached value : " + entry.getValue().toString());
		}
	}
	
	public static void addToCache(String requestKey, String newResponse) {
		MESSAGE_CACHE.put(requestKey, newResponse);
	}
	
	public static String updateCache(String hostname, ConsumerRecords<String, String> records) {
		
		String jsonString ="";
		KafkaClient client = new KafkaClient();
		
		try {
			ConsumerRecords<String, String> cRecords = client.kafkaConsumerPolling(hostname + ":9092");
			
			if(cRecords.isEmpty()) {
				String json = "{name: \"HildonJesu\", age: 37, city: \"Chennai\"}";
				populateConsumerRecords(cRecords);
				MESSAGE_CACHE.put("testkey1", json);
			} else {
				for (ConsumerRecord<String, String> record: cRecords) {
					MESSAGE_CACHE.put(record.key().toString(), record.value().toString());
					logger.debug( "\nMessage Key: " + record.key().toString() + " Message value : " + record.value().toString());
				}
			}
		} catch (Exception e1) {
			logger.error(e1.getMessage()); 
			e1.printStackTrace();
		}
		displayCache();
		
		return jsonString;		
	}	

	private static void populateConsumerRecords( ConsumerRecords<String, String> cRecords) {
		ConsumerRecord<String, String> record1 = new ConsumerRecord<String, String>(null, 10, 100, "sampleKey1", "SampleJSON1");
		ConsumerRecord<String, String> record2= new ConsumerRecord<String, String>(null, 10, 100, "sampleKey2", "SampleJSON2");
		//Poutlate CRecords with sample records;
	}
   
}
