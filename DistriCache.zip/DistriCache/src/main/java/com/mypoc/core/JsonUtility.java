package com.mypoc.core;

import java.io.File;
import java.io.IOException;
 



import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.mypoc.web.controller.HomeController;

@Component

   public class JsonUtility {
	
	static final Logger logger = Logger.getLogger(HomeController.class);
	
	public static final String XMLPATH ="/home/arul/files/documentExported.xml";
	public static final String DOWNLOAD_FILEPATH="/home/arul/files/demo";
	public static final String FILE_NAME="downloadedFile.xml";

	public static String XmlFileToJson(String xmlfilepath) {
		
		String data="";
		String jsonString ="";
		try
        {
            // Read the xml file
            data = FileUtils.readFileToString(new File(xmlfilepath), "UTF-8");
            
            // Create a new XmlMapper to read XML tags
            XmlMapper xmlMapper = new XmlMapper();
            
            //Reading the XML
            JsonNode jsonNode = xmlMapper.readTree(data.getBytes());
            
            logger.info("***Converting the XML : " + data);
            
            //Create a new ObjectMapper
            ObjectMapper objectMapper = new ObjectMapper();
            jsonString = objectMapper.writeValueAsString(jsonNode);
            
            logger.info("***Converted JSON : " + jsonString);

        } catch (JsonParseException e)
        {
        	logger.error("***Error : " + e.getMessage());
        	e.printStackTrace();
            
        } catch (JsonMappingException e)
        {
        	logger.error("***Error : " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e)
        {
        	logger.error("***Error : " + e.getMessage());
            e.printStackTrace();
        }
		return jsonString;		
	}
  
   /*public static void readDCRfilesAndLoadInJCR()throws Exception
    {		
		
		Repository repository = JcrUtils.getRepository();
         Session session = repository.login(new SimpleCredentials("admin", "admin".toCharArray()));
         try { 
             Node root = session.getRootNode(); 
             listFiles(DOWNLOAD_FILEPATH, root, session);
             
             OutputStream xmlDocumentStream = new FileOutputStream(XMLPATH);
             session.exportDocumentView("/", xmlDocumentStream, false, false);
             
         }finally { 
             session.logout(); 
         }         
	}
   
   private static void listFiles(String path, Node jcrroot, Session session)
	{
		System.out.println("inside listfiles from ..."+path);
		try {
			File folder = new File(path);
			File[] files = folder.listFiles();
	
			for (File file : files)
			{
				if (file.isFile())
				{					
					//addToJcr()
					if (!jcrroot.hasNode(file.getName())) {
						String filepath = path + "/" + file.getName();
						System.out.println("\nImporting the xml : "+filepath);
						
	                    // Create an unstructured node under which to import the XML 
	                    Node node = jcrroot.addNode(file.getName(), "nt:unstructured"); 
	                    System.out.println("Creating node in JCR for the file " + file.getName()); 
	                    // Import the DCR file under the created node 
	                    FileInputStream xmlStream = new FileInputStream(filepath);
	                    System.out.println("xmlStream :" + xmlStream); 
	                    session.importXML( 
	                                   node.getPath(), xmlStream, ImportUUIDBehavior.IMPORT_UUID_CREATE_NEW); 
	                    xmlStream.close();
	                    session.save(); 
	                    System.out.println("\nJCR Nodes are created. Root node is " + session.getRootNode().getName()); 
		                } 
					}
					else if (file.isDirectory())
					{
						System.out.println("Folder name : "+file.getName());
						Node foldernode = jcrroot.addNode(file.getName()); 
						listFiles(file.getAbsolutePath(),foldernode, session);
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	*/
}
