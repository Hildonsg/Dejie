package com.mypoc.core;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

public class CachingContextListener 
               implements ServletContextListener{
	
	static final Logger logger = Logger.getLogger(CachingContextListener.class);
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		logger.info("CachingContextListener ServletContextListener destroyed");
	}

        //Run this before web application is started
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		logger.info("CachingContextListener ServletContextListener started");
		
		//new WorkerThread("test");
	}
}