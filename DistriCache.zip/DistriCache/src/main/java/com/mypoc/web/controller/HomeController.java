package com.mypoc.web.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mypoc.core.DistriCacheImpl;
import com.mypoc.core.JsonUtility;
import com.mypoc.core.KafkaClient;

@Controller
public class HomeController {
	
	static final Logger logger = Logger.getLogger(HomeController.class);
	
	KafkaClient kafkaClient;
	JsonUtility jsonUtility;

    public JsonUtility getJsonUtility() {
		return jsonUtility;
	}

	@Autowired
	public void setJsonUtility(JsonUtility jsonUtility) {
		this.jsonUtility = jsonUtility;
	}

	public KafkaClient getKafkaClient() {
		return kafkaClient;
	}

	@Autowired
	public void setKafkaClient(KafkaClient kafkaClient) {
		this.kafkaClient = kafkaClient;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET) 
    public String welcomePage(ModelMap model) {
	  
	  model.addAttribute("msg", "Distributed Caching App.");
	  model.addAttribute("title","Distributed Caching Demo App");
	  return "jcr";
   }
	 
	
	@RequestMapping(value = "/initCache", method = RequestMethod.POST)
	public ModelAndView processSingleCache(
			@ModelAttribute("dcrname") String dcrFileName) {

		ModelAndView model = new ModelAndView();
		logger.info("Started processing: " + dcrFileName);

		try {

			DistriCacheImpl.initCache("localhost");
			logger.info("Successfully added message in Cache");

			model.addObject("successmsg", "Cache Successfully initiated.");

		} catch (Exception e) {

			logger.error("Exception while processing a DCR: " + dcrFileName
					+ " : " + e.getMessage());

			e.printStackTrace();
			model.addObject("errormsg",
					"Error while processing the request. Please check the logs for more details.");
		}

		model.setViewName("jcr");

		return model;
	}
	
	
	@RequestMapping(value = "/searchandqueueupdate", method = RequestMethod.POST)
	public ModelAndView searchAndPushResponseToKafka(@ModelAttribute("inputMessage") String inputMessage, BindingResult result) {

		logger.info("Started pushing To Kafka queue: " + inputMessage);
		logger.debug("Search text: " + inputMessage);
		

		ModelAndView model = new ModelAndView();
		String responseJson = "";
		try {
			
			if (null != DistriCacheImpl.lookupCache(inputMessage) ) {
				responseJson = DistriCacheImpl.lookupCache(inputMessage);
				model.addObject("response", responseJson);
			} else {
				responseJson = searchText(inputMessage);
				kafkaClient.callToKafka(inputMessage, responseJson);
			}
			logger.info("Successfully processed the message " + inputMessage);
			
		} catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
			e.printStackTrace();
		}
		
		model.setViewName("jcr");
		model.addObject("kafkamsg", responseJson);
		model.addObject("msg", "");
		
		return model;
	}

	private String searchText(String inputMessage) {
		
		String response =  new String ( "{name: \"Hildon\", status: \"Married\", age: 37, "
				+ "city: \"SingaporeCapital\"}" ); //TODO Write logic to search response from DB.
		
		response = response.replaceAll("Hildon", inputMessage);
		
		return response;
		
	}

}